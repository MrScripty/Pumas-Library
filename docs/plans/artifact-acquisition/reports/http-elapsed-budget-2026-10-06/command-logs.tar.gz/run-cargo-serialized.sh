#!/bin/bash
set -euo pipefail
source /workspace/.pumas-tools/env.sh
export CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR=/workspace/Pumas-Library/rust/target
exec flock /tmp/pumas-cargo-admission/cargo.lock cargo "$@"
