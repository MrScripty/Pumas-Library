import subprocess,pathlib,os,json
r=pathlib.Path('/workspace/scratch/http-elapsed-budget');p=r/'commands.json';env=os.environ.copy();env.update(CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0');wrapper='/tmp/pumas-cargo-admission/run-cargo-serialized';base=['--offline','--manifest-path','rust/Cargo.toml','--locked','-p','pumas-library'];tasks=[('default-acquisition',[wrapper,'test']+base+['--lib','acquisition::','--','--nocapture','--test-threads=1'])]
for features,mode in [([], 'default'),(['--no-default-features'],'no-default')]:
 tasks.append((mode+'-hf-download',[wrapper,'test']+base+['--lib']+features+['model_library::hf::download::tests::','--','--test-threads=1']))
 tasks.append((mode+'-hf-public-control',[wrapper,'test']+base+['--lib']+features+['public_hf_status_poll_tracks_mixed_size_download_through_receipt_settlement','--','--test-threads=1']))
 tasks.append((mode+'-clippy',[wrapper,'clippy']+base+['--all-targets']+features+['--','-D','warnings']))
tasks.append(('s3-clippy',[wrapper,'clippy']+base+['--features','s3','--all-targets','--','-D','warnings']))
for name,cmd in tasks:
 with (r/(name+'.log')).open('wb') as log:result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 metadata=json.loads(p.read_text());metadata['commands'].append({'name':name,'argv':cmd,'environment_overrides':{'CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0'},'log':name+'.log','exit':result.returncode,'source_blob':'83478facd105a08f8a52e36e6ce9780d09e76d2a'});p.write_text(json.dumps(metadata,indent=2)+'\n')
 print(name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
