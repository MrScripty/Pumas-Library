import pathlib,json,subprocess,os
r=pathlib.Path('/workspace/scratch/ac10-public-hf')
manifest=r/'commands.json'
env=os.environ.copy();env.update(CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
base=['/tmp/pumas-cargo-admission/run-cargo-serialized']
tasks=[]
for features,name in [([], 'default'),(['--no-default-features'],'no-default')]:
    tasks.append((name+'-clippy',base+['clippy','--offline','--manifest-path','rust/Cargo.toml','--locked','-p','pumas-library','--all-targets']+features+['--','-D','warnings']))
    tasks.append((name+'-mixed-size-control',base+['test','--offline','--manifest-path','rust/Cargo.toml','--locked','-p','pumas-library','--lib']+features+['public_hf_status_poll_tracks_mixed_size_download_through_receipt_settlement','--','--nocapture','--test-threads=1']))
for name,cmd in tasks:
    with (r/(name+'.log')).open('wb') as log:
        result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
    metadata=json.loads(manifest.read_text()); metadata['commands'].append({'name':name,'argv':cmd,'environment_overrides':{'CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0'},'log':name+'.log','exit':result.returncode});manifest.write_text(json.dumps(metadata,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    if result.returncode:raise SystemExit(result.returncode)
